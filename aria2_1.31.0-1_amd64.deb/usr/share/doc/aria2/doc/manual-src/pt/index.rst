.. Aria2 2.1.16.5 Documentação em Português
   sphinx-quickstart on Tue Apr 10 21:34:06 2012.
   tradução para portugues do BRASIL
   gilberto dos santos alves gsavix@gmail.com
   novembro/2012; revisão março/2013

.. meta::
   :description lang=pt: Manual Aria2 em português
   :keyword: programa para download gratuito, download android, download
             bittorrent, download linha de comando, download de músicas,
             download de ftp, download http, download https, mac OS/X,
             windows, linux, manual download aria2, torrent, download stream
   :author: gsavix@gmail.com tradução para português do brasil

.. index::	triple: Início; Cabeçalho; Manual

Manual Aria2
============

.. warning::

   This translation has been outdated quite sometime now, and lacks
   many recent changes.  Please consult English version manual for
   updated information.

aria2 é um utilitário para download de arquivos, que utiliza protocolos HTTP,
HTTPS, FTP, BitTorrent e Metalink. Pode efetuar download de um ou vários 
arquivos, a partir de uma ou múltiplas fontes e protocolos, com ou sem 
verificação de (checksum) integridade (md5, sha1, etc).

Também pode ser utilizado com ou sem proxy, proxy reverso e com outras opções.

Há suporte para download de arquivos, fragmentando-se o resultado em tamanhos
pré-determinados ou através da utilização de algoritmos que permitem 
assistir um filme ou ouvir a música enquanto o download está sendo feito.


Conteúdo:
=========

.. toctree::
   :maxdepth: 2

   aria2c
   README
